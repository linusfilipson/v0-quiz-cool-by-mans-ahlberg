import { QuizCard } from "@/components/quiz/quiz-card"

export default function Home() {
  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            Tech Quiz
          </h1>
          <p className="text-muted-foreground">
            Test your knowledge of web development
          </p>
        </div>
        <QuizCard />
      </div>
    </main>
  )
}
