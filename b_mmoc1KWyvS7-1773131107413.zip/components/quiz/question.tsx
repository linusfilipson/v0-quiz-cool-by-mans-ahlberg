"use client"

interface QuestionProps {
  text: string
}

export function Question({ text }: QuestionProps) {
  return (
    <h2 className="text-xl md:text-2xl font-semibold text-foreground text-balance">
      {text}
    </h2>
  )
}
