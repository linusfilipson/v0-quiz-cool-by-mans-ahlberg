"use client"

import { cn } from "@/lib/utils"

interface AnswerButtonProps {
  option: string
  index: number
  isSelected: boolean
  onClick: () => void
}

export function AnswerButton({ option, index, isSelected, onClick }: AnswerButtonProps) {
  const letters = ["A", "B", "C", "D"]

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full p-4 text-left rounded-lg border-2 transition-all duration-200",
        "hover:border-primary hover:bg-primary/5",
        "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
        isSelected
          ? "border-primary bg-primary/10 text-primary"
          : "border-border bg-card"
      )}
    >
      <span className="flex items-center gap-3">
        <span
          className={cn(
            "flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium",
            isSelected
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground"
          )}
        >
          {letters[index]}
        </span>
        <span className="text-foreground">{option}</span>
      </span>
    </button>
  )
}
