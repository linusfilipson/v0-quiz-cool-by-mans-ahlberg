"use client"

import { Button } from "@/components/ui/button"
import { RotateCcw } from "lucide-react"

interface RestartButtonProps {
  onClick: () => void
}

export function RestartButton({ onClick }: RestartButtonProps) {
  return (
    <Button onClick={onClick} size="lg" className="gap-2">
      <RotateCcw className="w-4 h-4" />
      Restart Quiz
    </Button>
  )
}
