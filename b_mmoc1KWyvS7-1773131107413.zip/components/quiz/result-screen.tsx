"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RestartButton } from "./restart-button"
import { Trophy, Target, Award } from "lucide-react"

interface ResultScreenProps {
  score: number
  total: number
  onRestart: () => void
}

export function ResultScreen({ score, total, onRestart }: ResultScreenProps) {
  const percentage = Math.round((score / total) * 100)

  const getMessage = () => {
    if (percentage === 100) return { text: "Perfect Score!", icon: Trophy }
    if (percentage >= 80) return { text: "Excellent Work!", icon: Award }
    if (percentage >= 60) return { text: "Good Job!", icon: Target }
    return { text: "Keep Practicing!", icon: Target }
  }

  const { text, icon: Icon } = getMessage()

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg">
      <CardHeader className="text-center pb-2">
        <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
          <Icon className="w-8 h-8 text-primary" />
        </div>
        <CardTitle className="text-2xl md:text-3xl">{text}</CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-6">
        <div className="space-y-2">
          <p className="text-5xl font-bold text-primary">{percentage}%</p>
          <p className="text-muted-foreground">
            You got <span className="font-semibold text-foreground">{score}</span> out of{" "}
            <span className="font-semibold text-foreground">{total}</span> questions correct
          </p>
        </div>
        <RestartButton onClick={onRestart} />
      </CardContent>
    </Card>
  )
}
