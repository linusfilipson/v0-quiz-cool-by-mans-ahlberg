"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ProgressBar } from "./progress-bar"
import { Question } from "./question"
import { AnswerButton } from "./answer-button"
import { ResultScreen } from "./result-screen"
import { quizQuestions } from "@/lib/quiz-data"
import { ArrowRight } from "lucide-react"

export function QuizCard() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [answers, setAnswers] = useState<number[]>([])
  const [showResults, setShowResults] = useState(false)

  const question = quizQuestions[currentQuestion]
  const isLastQuestion = currentQuestion === quizQuestions.length - 1

  const handleAnswerSelect = (index: number) => {
    setSelectedAnswer(index)
  }

  const handleNext = () => {
    if (selectedAnswer === null) return

    const newAnswers = [...answers, selectedAnswer]
    setAnswers(newAnswers)

    if (isLastQuestion) {
      setShowResults(true)
    } else {
      setCurrentQuestion((prev) => prev + 1)
      setSelectedAnswer(null)
    }
  }

  const handleRestart = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setAnswers([])
    setShowResults(false)
  }

  const calculateScore = () => {
    return answers.reduce((score, answer, index) => {
      return answer === quizQuestions[index].correctAnswer ? score + 1 : score
    }, 0)
  }

  if (showResults) {
    return (
      <ResultScreen
        score={calculateScore()}
        total={quizQuestions.length}
        onRestart={handleRestart}
      />
    )
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg">
      <CardHeader className="space-y-4">
        <ProgressBar current={currentQuestion} total={quizQuestions.length} />
      </CardHeader>
      <CardContent className="space-y-6">
        <Question text={question.question} />
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <AnswerButton
              key={index}
              option={option}
              index={index}
              isSelected={selectedAnswer === index}
              onClick={() => handleAnswerSelect(index)}
            />
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleNext}
          disabled={selectedAnswer === null}
          className="w-full gap-2"
          size="lg"
        >
          {isLastQuestion ? "See Results" : "Next Question"}
          <ArrowRight className="w-4 h-4" />
        </Button>
      </CardFooter>
    </Card>
  )
}
