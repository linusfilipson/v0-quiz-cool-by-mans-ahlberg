export interface Question {
  id: number
  question: string
  options: string[]
  correctAnswer: number
}

export const quizQuestions: Question[] = [
  {
    id: 1,
    question: "What does HTML stand for?",
    options: [
      "Hyper Text Markup Language",
      "High Tech Modern Language",
      "Home Tool Markup Language",
      "Hyperlink Text Management Language",
    ],
    correctAnswer: 0,
  },
  {
    id: 2,
    question: "Which of the following is a JavaScript framework?",
    options: ["Django", "Flask", "React", "Laravel"],
    correctAnswer: 2,
  },
  {
    id: 3,
    question: "What does CSS stand for?",
    options: [
      "Computer Style Sheets",
      "Cascading Style Sheets",
      "Creative Style System",
      "Colorful Style Sheets",
    ],
    correctAnswer: 1,
  },
  {
    id: 4,
    question: "Which method is used to add an element at the end of an array in JavaScript?",
    options: ["push()", "pop()", "shift()", "unshift()"],
    correctAnswer: 0,
  },
  {
    id: 5,
    question: "What is the correct way to declare a variable in modern JavaScript?",
    options: ["var x = 5", "let x = 5", "variable x = 5", "v x = 5"],
    correctAnswer: 1,
  },
]
